// src/main.js
document.getElementById('app').innerHTML = `<h1>LumiPad</h1>`;

// Register PWA service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js').catch(console.error);
  });
}
