// Minimal app + PWA registration & A2HS prompt
const el = document.getElementById('app');
if (el) {
  el.innerHTML = `
    <div class="floaty pulseGlow rounded-2xl p-6 bg-slate-800/60 shadow">
      <div class="text-lg font-semibold mb-3">Glowme status</div>
      <div class="flex gap-2 mb-4">
        <span class="pill bg-sky-500/20 text-sky-200">Hunger 50%</span>
        <span class="pill bg-lime-500/20 text-lime-200">Energy 70%</span>
        <span class="pill bg-fuchsia-500/20 text-fuchsia-200">Mood 65%</span>
      </div>
      <div class="flex gap-3">
        <button class="btn bg-sky-600/70">Feed</button>
        <button class="btn bg-lime-600/70">Rest</button>
        <button class="btn bg-fuchsia-600/70">Play</button>
      </div>
    </div>
  `;
}

// Register service worker
if ('serviceWorker' in navigator) {
  window.addEventListener('load', () => {
    navigator.serviceWorker.register('/service-worker.js')
      .catch(err => console.error('SW registration failed:', err));
  });
}

// Handle A2HS prompt
let deferredPrompt;
const installEl = document.getElementById('install');
const installBtn = document.getElementById('installBtn');

window.addEventListener('beforeinstallprompt', (e) => {
  e.preventDefault();
  deferredPrompt = e;
  if (installEl) installEl.classList.remove('hidden');
});

installBtn?.addEventListener('click', async () => {
  if (!deferredPrompt) return;
  deferredPrompt.prompt();
  const { outcome } = await deferredPrompt.userChoice;
  deferredPrompt = null;
  installEl?.classList.add('hidden');
});
