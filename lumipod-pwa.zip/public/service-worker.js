// Basic offline-first service worker with navigation fallback
const CACHE_NAME = 'lumipod-cache-v1';
const OFFLINE_URL = '/offline.html';

self.addEventListener('install', (event) => {
  event.waitUntil((async () => {
    const cache = await caches.open(CACHE_NAME);
    await cache.addAll([OFFLINE_URL]);
    self.skipWaiting();
  })());
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    // Clean old caches
    const keys = await caches.keys();
    await Promise.all(keys.map(k => (k !== CACHE_NAME) && caches.delete(k)));
    self.clients.claim();
  })());
});

self.addEventListener('fetch', (event) => {
  const { request } = event;

  // HTML navigation requests: network-first, fallback to cache, then offline page
  if (request.mode === 'navigate' || (request.method === 'GET' && request.headers.get('accept')?.includes('text/html'))) {
    event.respondWith((async () => {
      try {
        const networkResp = await fetch(request);
        // Update cache in the background
        const cache = await caches.open(CACHE_NAME);
        cache.put(request, networkResp.clone());
        return networkResp;
      } catch (err) {
        const cache = await caches.open(CACHE_NAME);
        const cached = await cache.match(request);
        return cached || cache.match(OFFLINE_URL);
      }
    })());
    return;
  }

  // For other requests: cache-first, then network
  event.respondWith((async () => {
    const cache = await caches.open(CACHE_NAME);
    const cached = await cache.match(request);
    if (cached) return cached;
    try {
      const resp = await fetch(request);
      // Only cache successful basic/opaque responses
      if (resp && (resp.status === 200 || resp.type === 'opaque')) {
        cache.put(request, resp.clone());
      }
      return resp;
    } catch (err) {
      // As a last resort, try offline page for HTML
      if (request.destination === 'document') {
        return cache.match(OFFLINE_URL);
      }
      throw err;
    }
  })());
});
