# Lumipod (PWA)

Installable PWA with offline fallback.

Click to deploy:

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=<REPLACE_WITH_YOUR_REPO_URL>)

## Notes
- Files in `/public` (service-worker, manifest, icons, offline.html) are copied to site root by Vite.
- `service-worker.js` uses navigation fallback to `/offline.html` and runtime caching for static assets.

## Local dev
```bash
npm i
npm run dev
```
